from plates import is_valid
def main():
    test_is_valid()

def test_is_valid():
    assert is_valid('123') == False
    assert is_valid('ABCSDFG') == False
    assert is_valid('AB12B') == False
    assert is_valid('ABG098') == False
    assert is_valid('AB!D') == False



if __name__ == "__main__":
    main()