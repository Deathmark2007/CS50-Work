import string
def main():
    plate = input("Plate: ")
    if is_valid(plate):
        print("Valid")
    else:
        print("Invalid")


def is_valid(s):
    if len(s) <= 6 and len(s) >= 2:
        if list(s)[0].isdigit() and list(s)[1].isdigit():
            return False

        else:

            for j in range(len(s)-1):
                if list(s)[j].isdigit() and list(s)[j+1].isalpha():
                    return False

            for i in range(len(s)):
                if str(list(s)[i]) == '0' and list(s)[i-1].isalpha():
                    return False
            for n in range(len(s)):
                if str(list(s)[n]) in list(string.punctuation) or str(list(s)[n]) == ' ':
                    return False
            return True


    else:
        return False

if __name__ == "__main__":
    main()