import sys
import csv
from tabulate import tabulate

def main():
    check_file()
    menu, header = pizza()
    print(menu[0]['cost1'])
    print(tabulate([ [header[0][0][0], header[0][0][1], header[0][0][2]],
        [menu[0]['name'], menu[0]['cost1'], menu[0]['cost2']], [menu[1]['name'],
        menu[1]['cost1'], menu[1]['cost2']],[menu[2]['name'], menu[2]['cost1'],
        menu[2]['cost2']],   [menu[3]['name'], menu[3]['cost1'], menu[3]['cost2']],
        [menu[4]['name'], menu[4]['cost1'], menu[4]['cost2']]], headers="firstrow", tablefmt="grid"))

def check_file():
    if len(sys.argv) < 2:
        sys.exit('Too few command-line arguments')
    elif len(sys.argv) > 2:
        sys.exit('Too many command-line arguments')
    elif ".csv" not in sys.argv[1]:
        sys.exit('Not a CSV file')
    else:
        try:
            open(sys.argv[1], "r")
        except FileNotFoundError:
            sys.exit('File does not exist')

def pizza():
    menu = []
    menu2 = []
    with open(sys.argv[1]) as file:
        pizza_name = csv.reader(file)
        menu2.append(list(pizza_name))
    with open(sys.argv[1]) as file:
        pizza_menu = csv.DictReader(file)
        for cost in pizza_menu:
            menu.append({"name":cost[menu2[0][0][0]], "cost1":cost[menu2[0][0][1]], "cost2":cost[menu2[0][0][2]]})
    return menu, menu2


#['Sicilian Pizza', 'Cheese', '1 item', '2 items', '3 items', 'Special']

if __name__ == "__main__":
    main()
