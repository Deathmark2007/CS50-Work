from response import validate
def main():
    test_count()


def test_count():
    assert validate('') == 'Invalid'
    assert validate('hello') == 'Invalid'
    assert validate('wilngo2007@gmail.com') == "Valid"


...


if __name__ == "__main__":
    main()
