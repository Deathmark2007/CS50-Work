code = int(input())
print(code*300000000**2)