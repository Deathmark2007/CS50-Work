import string

print("Greeting: ", end = '')
code = str(input())
code2 = list(code)
code3 = ''.join(code2).translate(str.maketrans('','', string.punctuation))
code3 = code3.lstrip()
code4 = code3.split(' ')

if code4[0] == "hello" or code4[0] == "Hello":
    print('$0')
elif code2[0] == "H" or code2[0] == 'h':
    print('$20')
else:
    print('$100')