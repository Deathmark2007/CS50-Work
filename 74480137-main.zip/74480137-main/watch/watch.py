import re
import sys


def main():
    print(parse(input("HTML: ")))


def parse(s):
    if match := re.search(r'(iframe)(.+)(src=")(https?://(www\.)?youtube\.com/embed/)(.+)(\>\</iframe\>)$',s):
        code = match.group(6).split('"')[0]
        return f"https://youtu.be/{code}"
    else:
        return "None"


...


if __name__ == "__main__":
    main()
