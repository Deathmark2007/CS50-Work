from pyfiglet import Figlet
import sys
figlet = Figlet()
try:
    if sys.argv[1] != '-f' and sys.argv[1] != '--font':
        sys.exit('Invalid usage')
except IndexError:
    pass
figlet.setFont(font = sys.argv[2])
code = input('Input: ')
print(figlet.renderText(code))
