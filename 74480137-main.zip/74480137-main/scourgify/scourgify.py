import sys
import csv

def main():
    check_file()
    write_file(get_file())




def check_file():
    if len(sys.argv) < 3:
        sys.exit('Too few command-line arguments')
    elif len(sys.argv) > 3:
        sys.exit('Too many command-line arguments')
    elif ".csv" not in sys.argv[1] or ".csv" not in sys.argv[2]:
        sys.exit('Not a CSV file')
    else:
        try:
            open(sys.argv[1], "r")
        except FileNotFoundError:
            sys.exit('File does not exist')

def write_file(x):
    with open(sys.argv[2], 'w') as file:
        new_file = csv.DictWriter(file, fieldnames = ['first', 'last', 'house'])
        new_file.writeheader()
        for people in x:
            new_file.writerow({'first':people['name'].split(', ')[1].strip(), 'last':people['name'].split(', ')[0].strip(), 'house':people['house'].strip()})

def get_file():
    code = []
    with open(sys.argv[1], 'r') as file:
        before = csv.DictReader(file)
        for people in before:
            code.append({'name':people['name'], 'house':people['house']})

    return code



if __name__ == "__main__":
    main()