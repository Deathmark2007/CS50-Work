from fpdf import FPDF

code = input('Name: ')

pdf = FPDF(orientation="portrait", format="A4")
pdf.set_margin(0)
pdf.add_page()
pdf.image("shirtificate.png", w = pdf.epw, h = pdf.eph/1.5, y = 47.5)
pdf.set_font('helvetica', 'B', 36)
pdf.cell(0, 18, 'CS50 Shirtificate', new_x="LMARGIN", new_y="NEXT", align='C')
pdf.set_text_color(255, 255, 255)
pdf.cell(0, 148.5, f"{code} took CS50", new_x="LMARGIN", new_y="NEXT", align='C')
pdf.output("shirtificate.pdf")