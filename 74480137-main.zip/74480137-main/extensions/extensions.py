print('File name: ', end='')
code2 = str(input())
code1 = code2.strip()
code = code1.lower()

if list(code)[-1] == 'f' and list(code)[-2] == 'i' and list(code)[-3] == 'g' and list(code)[-4] == '.':
    print('image/gif')

elif list(code)[-1] == 'g' and list(code)[-2] == 'p' and list(code)[-3] == 'j' and list(code)[-4] == '.':
    print('image/jpeg')

elif list(code)[-1] == 'g' and list(code)[-2] == 'e' and list(code)[-3] == 'p' and list(code)[-4] == 'j' and list(code)[-5] == '.':
    print('image/jpeg')

elif list(code)[-1] == 'g' and list(code)[-2] == 'n' and list(code)[-3] == 'p' and list(code)[-4] == '.':
    print('image/png')

elif list(code)[-1] == 'f' and list(code)[-2] == 'd' and list(code)[-3] == 'p' and list(code)[-4] == '.':
    print('application/pdf')

elif list(code)[-1] == 't' and list(code)[-2] == 'x' and list(code)[-3] == 't' and list(code)[-4] == '.':
    print('text/plain')

elif list(code)[-1] == 'p' and list(code)[-2] == 'i' and list(code)[-3] == 'z' and list(code)[-4] == '.':
    print('application/zip')

else:
    print('application/octet-stream')
