code = str.lower(input())
print(code)