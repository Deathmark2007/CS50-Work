import string
def main():
    code = input('Greeting: ')
    print(f"${str(value(code))}")


def value(greeting):
    code2 = greeting.translate(str.maketrans('','', string.punctuation)).lstrip().split(' ')
    if code2[0] == 'Hello' or code2 == 'hello':
        return 0
    elif code2[0][0] == "H" or code2[0][0] == "h":
        return 20
    else:
        return 100

if __name__ == "__main__":
    main()