''''
code = input()
code = code.split()
for i in range(len(code)):
    if code[i] == ":)":
        code.insert(code.index(":)"), "🙂")
        code.remove(":)")
    elif code[i] == ":(":
        code.insert(code.index(":("), "🙁")
        code.remove(":(")
print(" ".join(code))
'''
def convert(str):
    str_smiley = str.replace(":)", "🙂")
    str_frown = str_smiley.replace(":(", '🙁')
    print(str_frown)

def main():
    speak = input()
    convert(speak)
main()