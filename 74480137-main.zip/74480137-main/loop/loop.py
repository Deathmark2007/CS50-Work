x = 2
for i in range(5):
    x = x +2
print(x)