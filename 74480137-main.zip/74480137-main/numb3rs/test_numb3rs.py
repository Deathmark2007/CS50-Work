from numb3rs import validate

def main():
    test_validate


def test_validate():
    assert validate('255.255.255.255') == True
    assert validate('0.100.25.146') == True
    assert validate('255.276.255.255') == False
    assert validate('275.255.0.3') == False
    assert validate('cat') == False



if __name__ == "__main__":
    main()