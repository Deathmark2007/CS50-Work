import random


def main():
    code = get_level()
    score = 0
    help = 0
    for i in range(10):
        num1, num2 = generate_integer(code).split(' ')
        code2 = input(f'{num1} + {num2} = ')
        if int(code2) == (int(num1) + int(num2)):
            score += 1
        while int(code2) != (int(num1) + int(num2)):
            help += 1
            print('EEE')
            if help >= 3:
                print(f'{num1} + {num2} = {int(num1) + int(num2)}')
                break
            code2 = input(f'{num1} + {num2} = ')
    print(f'Score: {score}')

def get_level():
    accepted_numbers = ['1', '2', '3']
    while True:
        code2 = input('Level: ')
        if str(code2) not in accepted_numbers:
            pass
        else:
            return code2


def generate_integer(level):
    if level == '1':
        return str(random.randint(0, 9)) + ' ' + str(random.randint(0, 9))
    if level == '2':
        return str(random.randint(10, 99)) + ' ' +str(random.randint(10, 99))
    if level == '3':
        return str(random.randint(100, 999)) + ' ' +str(random.randint(100, 999))

if __name__ == "__main__":
    main()
