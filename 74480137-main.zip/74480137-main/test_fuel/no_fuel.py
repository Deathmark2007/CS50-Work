def main():
    print(no_gauge(no_convert(input('Fraction: '))))


def no_convert(fraction):
    while True:
        try:
            x, y = fraction.split('/')
        except ValueError:
            pass
        else:
            try:
                z = '{:.0%}'.format(int(x)/int(y))
            except (ValueError, ZeroDivisionError):
                pass

            else:
                if int(z.strip('%')) <= 100:
                    return int(z.strip('%'))

        fraction = input('Fraction: ')

def no_gauge(percentage):
    if percentage >= 99:
        return "E"
    elif percentage <= 1:
        return "F"
    else:
        return f'{percentage}%'



if __name__ == "__main__":
    main()