def main():
    print(gauge(convert(input('Fraction: '))))


def convert(fraction):
    while True:
        try:
            x, y = fraction.split('/')
        except ValueError:
            raise
        else:
            try:
                z = int(x)/int(y)*100
            except (ValueError, ZeroDivisionError):
                raise
            else:
                if z <= 100:
                    return int(z)

        fraction = input('Fraction: ')

def gauge(percentage):
    if percentage >= 99:
        return "F"
    elif percentage <= 1:
        return "E"
    else:
        return f"{int(percentage)}%"



if __name__ == "__main__":
    main()