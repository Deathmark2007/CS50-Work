print('What is The Answer to the Great Question Of Life, the Universe and Everything?')
code = str(input())
if code == '42':
    print('Yes')
elif code == 'forty two':
    print('Yes')
elif code == 'forty-two':
    print('Yes')
elif code == 'FoRty TwO':
    print('Yes')
elif code == ' 42  ':
    print('Yes')
else:
    print('No')