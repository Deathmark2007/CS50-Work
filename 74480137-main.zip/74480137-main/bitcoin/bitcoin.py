import sys
import requests
import decimal

if len(sys.argv) != 2:
    sys.exit('Missing command-line argument')
try:
    decimal.Decimal(sys.argv[1])
except decimal.InvalidOperation:
    sys.exit('Comand-line argument is not a number')
r = requests.get("https://api.coindesk.com/v1/bpi/currentprice.json")
code = r.json()['bpi']['USD']['rate']
code2 = list(r.json()['bpi']['USD']['rate'])
for i in range(len(code)):
    if list(code)[i] == ',':
        code2.remove(',')
code3 = float(''.join(code2)) * float(str(sys.argv[1]))
print(f"${code3:,.4f}")
