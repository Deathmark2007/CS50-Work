print('Expression: ', end = '')
code = input()
code1 = round(eval(code), 1)
if '.' in list(str(code1)):
    print(code1)
else:
    print(code1, ".0", sep = '')