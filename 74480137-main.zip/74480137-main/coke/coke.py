coke = 50
while coke > 0:
    print('Amount Due:', str(coke))
    print('Insert Coin: ', end ='')
    money = input()
    if int(money) == 25 or int(money) == 10 or int(money) == 5:
        coke = coke - int(money)
if coke == 0:
    print('Changed Owed: 0')
if coke < 0:
    coke = abs(coke)
    print('Changed Owed:', str(coke))

