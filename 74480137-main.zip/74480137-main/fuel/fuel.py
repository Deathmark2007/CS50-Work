def main():
    b = fuel_gauge()
    if b <= 1/100:
        print('E')
    elif b == 1 or b == 99/100:
        print('F')
    elif b > 1:
        b = fuel_gauge()
    else:
        print('{:.0%}'.format(b))

def fuel_gauge():
    while True:
        try:
            x, y = input('Fractions: ').split('/')
        except ValueError:
            pass
        else:
            while True:
                try:
                    return int(x)/ int(y)
                except ValueError:
                    break
                except ZeroDivisionError:
                    break

main()