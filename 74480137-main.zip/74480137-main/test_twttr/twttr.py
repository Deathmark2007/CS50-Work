def main():
    code = input('Input: ')
    print(f"Output: {shorten(code)}")


def shorten(word):
    code1 = []
    for i in range(len(list(word))):
        if list(word)[i] not in ['a', 'A', 'E', 'e', 'i', 'I', 'o', 'O', 'u', 'U']:
            code1.append(list(word)[i])
    return ''.join(code1)

if __name__ == "__main__":
    main()