from twttr import shorten
def main():
    test_shorten()

def test_shorten():
    assert shorten('hEllo1.') == 'hll1.'
#    assert shorten('BYE!!!!!') == 'Output: BY!!!!!'
#    assert shorten('Just set up my Twitter!!!') == 'Output: Jst st p my Twttr!!!'


if __name__ == "__main__":
    main()