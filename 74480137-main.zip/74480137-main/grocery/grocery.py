code = []
while True:
    try:
        code.append(input().upper())
    except EOFError:
        break
code = sorted(code)
print()
code2 = {}

for i in range(len(code)):
    if code[i] in code2:
        code2[code[i]] = code2[code[i]] + 1
    elif code[i] not in code2:
        code2[code[i]] = 1

for i in range(len(code2)):
    print(code2.get(list(code2)[i]), list(code2)[i])


