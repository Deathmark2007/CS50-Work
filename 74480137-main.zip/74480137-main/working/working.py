import re
import sys


def main():
    print(convert(input("Hours: ")))


def convert(s):
    if re.search(r'(1[0-2]|[1-9]|1[0-2](:[0-5][0-9])|[1-9](:[0-5][0-9])) (AM|PM) to (1[0-2]|[1-9]|1[0-2](:[0-5][0-9])|[1-9](:[0-5][0-9])) (AM|PM)', s):
        time1, time2 = s.split(' to ')
        time1 = list(re.split(':| ', time1))
        time2 = list(re.split(':| ', time2))

        if "PM" in time1:
            time1[0] = str(int(time1[0]) + 12)
            time1.remove("PM")
        elif "AM" in time1 and "12" in time1:
            time1[0] = "0"
            time1.remove("AM")
        else:
            time1.remove("AM")
        if len(time1) == 1:
            time1.insert(1, ":00")
        else:
            time1.insert(1, ":")
        if int(time1[0]) ==24:
            time1[0] = str(int(time1[0])-12)
        if int(time1[0]) < 10:
            time1.insert(0, '0')

        if "PM" in time2:
            time2[0] = str(int(time2[0]) + 12)
            time2.remove("PM")
        elif "AM" in time2 and "12" in time2:
            time2[0] = "0"
            time2.remove("AM")
        else:
            time2.remove("AM")
        if len(time2) == 1:
            time2.insert(1, ":00")
        else:
            time2.insert(1, ":")
        if int(time2[0]) ==24:
            time2[0] = str(int(time2[0])-12)
        if int(time2[0]) < 10:
            time2.insert(0, '0')
        return f"{''.join(time1)} to {''.join(time2)}"


    else:
        raise ValueError



...


if __name__ == "__main__":
    main()