try:
    print(f'x is {int(input())}')
except ValueError:
    print('no')