import sys
def main():
    check_file()
    print(lines())

def check_file():
    if len(sys.argv) < 2:
        sys.exit('Too few command-line arguments')
    elif len(sys.argv) > 2:
        sys.exit('Too many command-line arguments')
    elif ".py" not in sys.argv[1]:
        sys.exit('Not a python file')
    else:
        try:
            open(sys.argv[1], "r")
        except FileNotFoundError:
            sys.exit('File does not exist')

def lines():
    with open(sys.argv[1], "r") as file:
        lines = file.readlines()
        num_lines = len([l for l in lines if l.strip(' \n') != '' and '#' != list(l.strip(' \n') + 'a')[0]])
        return num_lines


if __name__ == "__main__":
    main()
