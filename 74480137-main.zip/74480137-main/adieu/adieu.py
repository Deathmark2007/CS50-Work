name = []
while True:
    try:
        code = input('Name: ')
    except EOFError:
        print()
        break
    else:
        name.append(code)

print('Adieu, adieu, to ', end='')
for i in range(len(name)):
    #print(i)
    #print(name[i])
    #print(name[-1])
    #print(name)
    #print(len(name))
    if int(i) == 0 and len(name) > 1:
        print(f'{name[i]}', end = '')

    elif int(i) == 0:
        print(f'{name[i]}')

    elif name[i] == name[-1] and int(len(name)) == 2:
        print(f' and {name[i]}')

    elif name[i] != name[-1]:
        print(f', {name[i]}', end='')

    elif name[i] == name[-1] and int(len(name)) > 2:
        print(f', and {name[i]}')
