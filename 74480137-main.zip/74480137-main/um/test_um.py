from um import count
def main():
    test_count()


def test_count():
    assert count('um') == 1
    assert count("um?") == 1
    assert count('Um, thanks, um...') == 2
    assert count('yummy pie') == 0
    assert count(' um ')



...


if __name__ == "__main__":
    main()
