import random
while True:
    code = input('Level: ')
    try:
        if int(code) > 0:
            break
    except:
        pass
guess = random.randint(1, int(code))
while True:
    code2 = input('Guess: ')
    try:
        if int(code2) == guess:
            print('Just right!')
            break
    except ValueError:
        pass
    else:
        try:
            if int(code2) > guess:
                print('Too large!')
                pass
        except ValueError:
            pass
        else:
            try:
                if int(code2) < guess:
                    print('Too small!')
                    pass
            except ValueError:
                pass
            else:
                pass
