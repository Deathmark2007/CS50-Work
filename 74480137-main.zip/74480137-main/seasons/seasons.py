import inflect
from datetime import date
import sys


def main():
    print(date_to_word(subtract_date(check_date(input("Date of Birth: ")))))

def check_date(s):
    try:
        date.fromisoformat(s)
    except:
        sys.exit('Invalid Date')
    else:
        return s

def subtract_date(s):
    years, months, days = s.split('-')
    date_difference =date.today() - date(int(years), int(months), int(days))
    return divmod(date_difference.total_seconds(), 60)[0]

def date_to_word(s):
    p = inflect.engine()
    return f"{p.number_to_words(int(s), andword='').capitalize()} minutes"


if __name__ == "__main__":
    main()


