from seasons import check_date, subtract_date, date_to_word
import pytest

def main():
    test_check_date()
    test_subtract_date()
    check_date_to_word()



def test_check_date():
    assert check_date('1999-12-31') == "1999-12-31"
    with pytest.raises(SystemExit):
        check_date('100')


def test_subtract_date():
    assert subtract_date('1999-12-31') == 12088800.0
    with pytest.raises(ValueError):
        subtract_date('0')

def check_date_to_word():
    assert date_to_word(12088800.0) == "Twelve million, eighty-eight thousand, eight hundred minutes"
    with pytest.raises(ValueError):
        date_to_word('hello')

if __name__ == "__main__":
    main()
