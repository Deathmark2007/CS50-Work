import inflect
from datetime import date
import re

class Time:
    def __init__(self, time):
        self.time = time

    def __str__(self):
        p = inflect.engine()
        return p.number_to_words(self.time, andword="")

    @property
    def time(self):
        return self._time

    @time.setter
    def time(self, time):
        if not re.search(f"([0-9])+-(1[0, 2]|[2468])", time):
            raise ValueError('not time')
        self._time=time

    @classmethod
    def get(cls):
        time = input('Date of Birth: ')
        return cls(time)


def main():
    code = Time.get()
    print(code)



if __name__ == "__main__":
    main()


