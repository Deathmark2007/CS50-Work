import emoji
code = input('Input: ')
print(emoji.emojize(f'Output: {code}'))