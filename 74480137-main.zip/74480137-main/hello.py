name = input("What is you name ")
i = len(str.split(name))
name = str.split(str.strip(name))
print(name)

for x in range(i):
    name = str.capitalize(name[i-1])
    print(name)

print("hello, " + ' '.join(name[0]))
print(name)