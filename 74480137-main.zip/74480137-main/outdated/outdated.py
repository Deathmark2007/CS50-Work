month = ["January","February","March","April","May","June","July","August","September","October","November","December"]
code = input('Date: ')
code = code.strip()
while True:
    if '/' in code:
        code = code.split('/')
        if code[0] in month:
            pass 
        elif int(code[1]) > 31 or int(code[0]) > 12:
            pass
        else:
            break
    elif ',' in code:
        try:
            code = code.split(' ', 1)
        except IndexError:
            pass
        else:
            try:
                code1 = code[1].split(', ')
            except IndexError:
                pass
            else:
                code.pop()
                code.extend((code1[0], code1[1]))
                if code[0] not in month or int(code[1]) > 31:
                    pass
                else:
                    break
    code = input('Date: ')

for i in range(len(month)):
    if code[0] == month[i]:
        code[0] = i+1
if int(code[0]) < 10:
    code[0] = f'0{code[0]}'
if int(code[1]) < 10:
    code[1] = f"0{code[1]}"
print(f"{code[2]}-{code[0]}-{code[1]}")
