print('camelCase: ', end = '')
code = str(input())
code1 = []
for i in range(len(list(code))):
    if list(code)[i].isupper():
        code1.append('_')
        code1.append(list(code)[i].lower())
    else:
        code1.append(list(code)[i])
print('snake_case:', ''.join(code1))