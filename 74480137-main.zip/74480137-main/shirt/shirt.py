import sys
from PIL import Image, ImageOps
def main():
    check_file()
    
    shirt = Image.open('shirt.png')
    try:
        code = Image.open(sys.argv[1])
    except FileNotFoundError:
        sys.exit('Input does not exist')
    shirt_size = shirt.size
    code2 = ImageOps.fit(code, shirt_size)
    code2.paste(shirt, shirt)
    code2.save(sys.argv[2])

def check_file():
    check = ('.jng', '.jpeg', '.png')
    if len(sys.argv) < 3:
        sys.exit('Too few command-line arguments')
    elif len(sys.argv) > 3:
        sys.exit('Too many command-line arguments')
    elif sys.argv[1].endswith(check) and sys.argv[2].endswith(check):
        sys.exit('Invalid input')
    elif sys.argv[1][-3:] != sys.argv[2][-3:]:
        sys.exit('Input and output have different extensions')




if __name__ == "__main__":
    main()
