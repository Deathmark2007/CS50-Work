code = input()
print(code.replace(' ', '...'))