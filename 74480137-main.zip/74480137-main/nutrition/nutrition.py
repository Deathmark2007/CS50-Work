print('Item: ', end = '')
code = input().lower()

if code == 'apple':
    print('130')
elif code in ['avocado','cantaloupe','honeydew melon','pineapple','strawberries','tangerine']:
    print('50')
elif code == 'banana':
    print('110')
elif code in ['grapefruit','nectarine','peach']:
    print('60')
elif code in ['grapes', 'kiwifruit']:
    print('90')
elif code == 'lemon':
    print('15')
elif code == 'lime':
    print('20')
elif code in ['orange','watermelon']:
    print('80')
elif code in ['pear', 'sweet cherries']:
    print('100')
elif code == 'plums':
    print('70')
