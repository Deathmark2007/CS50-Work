def main():
    print('What time is it? ', end = '')
    code = str(input())
    convert(code)


def convert(time):
    hours, minutes = time.split(':')
    if hours >= '7' and hours <= '8':
        if minutes < '60' and hours < '8':
            print('breakfast time')
        if minutes == '00' and hours == '8':
            print('breakfast time')

    if hours >= '12' and hours <= '13':
        if minutes < '60' and hours < '13':
            print('lunch time')
        if minutes == '00' and hours == '13':
            print('lunch time')

    if hours >= '18' and hours <= '19':
        if minutes < '60' and hours < '19':
            print('dinner time')
        if minutes == '00' and hours == '19':
            print('dinner time')



if __name__ == "__main__":
    main()


