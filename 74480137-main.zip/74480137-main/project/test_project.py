import pytest
from project import calculate_hp, find_pokemon, calculate_damage, get_poke_file, get_move_file, calculate_stat

def main():
    test_find_pokemon()
    test_calculate_damage()
    test_get_poke_file()
    test_get_move_file()
    test_calculate_hp()
    test_calculate_stat()

def test_find_pokemon():
    assert find_pokemon('garchomp', 'pikachu', 'earthquake')
    with pytest.raises(ValueError):
        assert find_pokemon('garchome', 'pikachu', 'earthquake')
    with pytest.raises(ValueError):
        assert find_pokemon('', 'pikachu', 'earthquake')
    with pytest.raises(ValueError):
        assert find_pokemon('garchomp', 'pikacha', 'earthquake')
    with pytest.raises(ValueError):
        assert find_pokemon('garchomp', '', 'earthquake')
    with pytest.raises(ValueError):
        assert find_pokemon('garchomp', 'pikachu', 'earthpower')
    with pytest.raises(ValueError):
        assert find_pokemon('garchomp', 'pikachu', '')

def test_calculate_damage():
    assert calculate_damage([['garchomp', 78, 253], ['pikachu', 289, 193], ['earthquake', 100, 1.5]]) == 'garchomp does 132.0 to pikachu using earthquake, pikachu has 157 hp left'

def test_get_poke_file():
    assert get_poke_file() == [{'name': 'garchomp', 'level': '78', 'hp': '289', 'atk': '253', 'def': '193', 'spa': '151', 'spd': '171', 'spe': '171'}, {'name': 'pikachu', 'level': '78', 'hp': '289', 'atk': '253', 'def': '193', 'spa': '151', 'spd': '171', 'spe': '171'}]

def test_get_move_file():
    assert get_move_file() == [{'name': 'earthquake', 'base_power': '100', 'physical/special': 'physical', 'crit': '1.5'}, {'name': 'flame thrower', 'base_power': '90', 'physical/special': 'special', 'crit': '1'}]

def test_calculate_hp():
    assert calculate_hp(100, 78, 31, 252) == 360
    with pytest.raises(ValueError):
        calculate_hp(100, 256, 31, 252)
    with pytest.raises(ValueError):
        calculate_hp(100, 0, 31, 252)

def test_calculate_stat():
    assert calculate_stat(100, 90, 31, 248) == 278
    with pytest.raises(ValueError):
        calculate_hp(100, 256, 31, 252)
    with pytest.raises(ValueError):
        calculate_hp(100, 0, 31, 252)

if __name__ == "__main__":
    main()