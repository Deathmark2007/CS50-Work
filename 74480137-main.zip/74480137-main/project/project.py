import sys
import csv


def main():
    while True:
        question = input('Create or Calculate or Cancel: ')
        if question.upper() == 'CALCULATE':
            print(calculate_damage(find_pokemon(input('Enter in the attacking pokemon: '), input('Enter in the defending pokemon: '), input('Enter in the attacking move: '))))



        elif question.upper() == 'CREATE':
            poke_move = input('Create pokemon or move? ')
            if poke_move.upper() == 'POKEMON':
                create_poke(input('Pokemon name: '), get_poke_file())
            elif poke_move.upper() == "MOVE":
                create_move(input('Move name: '), get_move_file())
            else:
                raise ValueError('Not an option')
        elif question.upper() == 'CANCEL':
            pass
        else:
            raise ValueError('Did not choose any of the options')

        question2 = input('Cancel calculation? Y/N: ')
        if question2.upper() == 'Y':
            sys.exit('Canceled calcualtion')
        elif question2.upper() == 'N':
            pass
        else:
            raise ValueError('Not an option')

def find_pokemon(code, code2, code3):
    poke1 = []
    lines = open('POKEMON.csv', 'r').read()
    lines2 = open('MOVE.csv', 'r').read()
    for i in lines.split(f"\n"):
        if code in i:
            poke1.append(i)
    if code not in lines or not code:
        raise ValueError(f'The pokemon {code} not found')
    if code2 not in lines or not code2:
        raise ValueError(f'The pokemon {code2} not found')
    if code3 not in lines2 or not code3:
        raise ValueError(f'The pokemon {code3} not found')


    poke2 = []
    for n in lines.split(f"\n"):
        if code2 in n:
            poke2.append(n)
    if code2 not in lines:
        raise ValueError(f'The pokemon {code2} not found')


    lines2 = open('MOVE.csv', 'r').read()
    move = []
    for j in lines2.split(f"\n"):
        if code3 in j:
            move.append(j)
    if code3 not in lines2:
        raise ValueError(f'The move {code3} not found')

    poke_stat = []
    poke2_stat = []
    move_stat = []
    move_stat.append(''.join(move).split(',')[0])
    move_stat.append(int(''.join(move).split(',')[1]))
    move_stat.append(float(''.join(move).split(',')[3]))

    poke_stat.append(''.join(poke1).split(',')[0])
    poke_stat.append(int(''.join(poke1).split(',')[1]))

    poke2_stat.append(''.join(poke2).split(',')[0])
    poke2_stat.append(int(''.join(poke2).split(',')[2]))

    if ''.join(move).split(',')[2] == 'physical':
        poke_stat.append(int(''.join(poke1).split(',')[3]))
        poke2_stat.append(int(''.join(poke2).split(',')[4]))
    elif ''.join(move).split(',')[2] == 'special':
        poke_stat.append(int(''.join(poke1).split(',')[5]))
        poke2_stat.append(int(''.join(poke2).split(',')[6]))
    return [poke_stat, poke2_stat, move_stat]

def calculate_damage(info):
    poke1 = info[0]
    poke2 = info[1]
    move = info[2]
    damage = (int((int((int(((2*poke1[1])/5))+2)*move[1]*poke1[2]/poke2[2]))/50)+2)*move[2]
    final_damage = poke2[1]-int(damage)
    return f"{poke1[0]} does {damage} to {poke2[0]} using {move[0]}, {poke2[0]} has {final_damage} hp left"




def create_poke(name, x):
    lines = open('POKEMON.csv', 'r').read()
    if name in lines:
        ask_to_edit = input(f"{name} found in pokemon list, do you want to edit it? Y/N: ")
        if ask_to_edit.upper() == 'Y':
            edited_file = edit_poke_file(name)
            with open('POKEMON.csv', 'w') as file:
                poke_file = csv.DictWriter(file, fieldnames = ['name','level', 'hp', 'atk', 'def', 'spa', 'spd', 'spe'])
                poke_file.writeheader()
                for pokemon in edited_file:
                    poke_file.writerow({'name':pokemon['name'], 'level':pokemon['level'], 'hp':pokemon['hp'], 'atk':pokemon['atk'], 'def':pokemon['def'], 'spa':pokemon['spa'], 'spd':pokemon['spd'], 'spe':pokemon['spe']})
            return

        elif ask_to_edit.upper()== "N":
            return
        else:
            raise ValueError('Not an option')

    with open('POKEMON.csv', 'w') as file:
        poke_file = csv.DictWriter(file, fieldnames = ['name','level', 'hp', 'atk', 'def', 'spa', 'spd', 'spe'])
        poke_file.writeheader()
        for pokemon in x:
            poke_file.writerow({'name':pokemon['name'], 'level':pokemon['level'],'hp':pokemon['hp'], 'atk':pokemon['atk'], 'def':pokemon['def'], 'spa':pokemon['spa'], 'spd':pokemon['spd'], 'spe':pokemon['spe']})

        level = int(input('level: '))
        if level > 100 or level < 0:
            raise ValueError('Invalid Level')
        hp = calculate_hp(level, int(input('hp base stat: ')), int(input('hp IV: ')), int(input('hp EV: ')))
        atk = calculate_stat(level, int(input('atk base stat: ')), int(input('atk IV: ')), int(input('atk EV: ')))
        _def = calculate_stat(level, int(input('def base stat: ')), int(input('def IV: ')), int(input('def EV: ')))
        spa = calculate_stat(level, int(input('spa base stat: ')), int(input('spa IV: ')), int(input('spa EV: ')))
        spd = calculate_stat(level, int(input('spd base stat: ')), int(input('spd IV: ')), int(input('spd EV: ')))
        spe = calculate_stat(level, int(input('spe base stat: ')), int(input('spe IV: ')), int(input('spe EV: ')))
        poke_file.writerow({'name':name,'level':level, 'hp': hp, 'atk':atk, 'def':_def, 'spa':spa, 'spd':spd, 'spe':spe})
    return

def calculate_hp(level = 1, base_stat = 1, IV = 0, EV = 0):
    if base_stat > 255 or base_stat < 1:
        raise ValueError('Invalid Base Stat')
    if IV > 31 or IV < 0:
        raise ValueError('Invalid IV')
    if IV > 252 or IV < 0:
        raise ValueError('Invalid EV')
    hp = (int(((2*base_stat+IV+int((EV/4)))*level)/100))+level+10
    return hp


def calculate_stat(level = 1, base_stat = 0, IV = 0, EV = 0):
    if base_stat > 255 or base_stat < 1:
        raise ValueError('Invalid Base Stat')
    if IV > 31 or IV < 0:
        raise ValueError('Invalid IV')
    if IV > 252 or IV < 0:
        raise ValueError('Invalid EV')
    stat = (int(((2*base_stat+IV+int((EV/4)))*level)/100))+5
    return stat


def get_poke_file():
    _get_file = []
    with open("POKEMON.csv", 'r') as file:
        data = csv.DictReader(file)
        for pokemon in data:
            _get_file.append({'name':pokemon['name'],'level':pokemon['level'], 'hp':pokemon['hp'], 'atk':pokemon['atk'], 'def':pokemon['def'], 'spa':pokemon['spa'], 'spd':pokemon['spd'], 'spe':pokemon['spe']})
    return _get_file

def edit_poke_file(name):
    _edit_file = []
    with open("POKEMON.csv", 'r') as file:
        data = csv.DictReader(file)
        for pokemon in data:
            if pokemon['name'] == name:
                print('please enter new stats')
                level = int(input('level: '))
                if level > 100 or level < 0:
                    raise ValueError('Invalid Level')
                hp = calculate_hp(level, int(input('hp base stat: ')), int(input('hp IV: ')), int(input('hp EV: ')))
                atk = calculate_stat(level, int(input('atk base stat: ')), int(input('atk IV: ')), int(input('atk EV: ')))
                _def = calculate_stat(level, int(input('def base stat: ')), int(input('def IV: ')), int(input('def EV: ')))
                spa = calculate_stat(level, int(input('spa base stat: ')), int(input('spa IV: ')), int(input('spa EV: ')))
                spd = calculate_stat(level, int(input('spd base stat: ')), int(input('spd IV: ')), int(input('spd EV: ')))
                spe = calculate_stat(level, int(input('spe base stat: ')), int(input('spe IV: ')), int(input('spe EV: ')))
                _edit_file.append({'name':name, 'hp': hp, 'atk':atk, 'def':_def, 'spa':spa, 'spd':spd, 'spe':spe})
            else:
                _edit_file.append({'name':pokemon['name'], 'level':pokemon['level'], 'hp':pokemon['hp'], 'atk':pokemon['atk'], 'def':pokemon['def'], 'spa':pokemon['spa'], 'spd':pokemon['spd'], 'spe':pokemon['spe']})

    return _edit_file


def create_move(name, x):
    lines = open('MOVE.csv', 'r').read()
    if name in lines:
        ask_to_edit = input(f"{name} found in move list, do you want to edit it? Y/N: ")
        if ask_to_edit.upper() == 'Y':
            edited_file = edit_move_file(name)
            with open('MOVE.csv', 'w') as file:
                move_file = csv.DictWriter(file, fieldnames = ['name','base_power', 'physical/special', 'crit'])
                move_file.writeheader()
                for move in edited_file:
                    move_file.writerow({'name':move['name'], 'base_power':move['base_power'], 'physical/special':move['physical/special'], 'crit':move['crit']})
            return

        elif ask_to_edit.upper()== "N":
            return
        else:
            raise ValueError('Not an option')

    with open('MOVE.csv', 'w') as file:
        move_file = csv.DictWriter(file, fieldnames = ['name', 'base_power', 'physical/special', 'crit'])
        move_file.writeheader()
        for move in x:
            move_file.writerow({'name':move['name'], 'base_power':move['base_power'], 'physical/special':move['physical/special'], 'crit':move['crit']})
        base_power = int(input('base_power: ' ))
        p_or_s = input('physical or special move? ')
        if p_or_s.upper() not in ["PHYSICAL", "SPECIAL"]:
            raise ValueError('Not an option')
        crit = input('crit? Y/N:')
        crit_value = 1
        if crit.upper() == 'Y':
            crit_value = 1.5
        elif crit.upper() == 'N':
            crit_value = 1
        else:
            raise ValueError('Not an option')
        move_file.writerow({'name':name, 'base_power':base_power, 'physical/special':p_or_s, 'crit': crit_value})

def get_move_file():
    _get_file = []
    with open("MOVE.csv", 'r') as file:
        data = csv.DictReader(file)
        for pokemon in data:
            _get_file.append({'name':pokemon['name'], 'base_power':pokemon['base_power'], 'physical/special':pokemon['physical/special'], 'crit':pokemon['crit']})
    print(_get_file)
    return _get_file



def edit_move_file(name):
    _edit_file = []
    with open("MOVE.csv", 'r') as file:
        data = csv.DictReader(file)
        for move in data:
            if move['name'] == name:
                print('please enter new stats')
                base_power = int(input('base_power: ' ))
                p_or_s = input('physical or special move: ')
                if p_or_s.upper() not in ["PHYSICAL", "SPECIAL"]:
                    raise ValueError('Not an option')
                crit = input('crit? Y/N:')
                crit_value = 1
                if crit.upper() == 'Y':
                    crit_value = 1.5
                elif crit.upper() == 'N':
                    crit_value = 1
                else:
                    raise ValueError('Not an option')
                _edit_file.append({'name':name, 'base_power':base_power, 'physical/special':p_or_s, 'crit':crit_value})
            else:
                _edit_file.append({'name':move['name'], 'base_power':move['base_power'], 'physical/special':move['physical/special'], 'crit':move['crit']})
    print(_edit_file)
    return _edit_file

if __name__ == "__main__":
    main()